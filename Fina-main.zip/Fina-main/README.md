# Fina

Realizzazione di un sito web per l'Autolavaggio Fina di Busto Garolfo ad opera di Manfrin Luca.

Realizzazione avvenuta combinando diversi linguaggi di mark-up come: HTML5, CSS e con l'inserimento di script in linguaggio JavaScript.

Successivamente è stato acquisito il dominio www.autolavaggiofina.it e tramite un servizio di hosting dedicato è stato reso possibile il deploy del sito.

Manfrin Luca, Università degli Studi di Milano.
